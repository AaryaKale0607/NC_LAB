#include<cmath>
#include <vector>
#include <algorithm>
#include <iomanip>
#include "include/iterative_solver.hpp"
#include "include/gaussian_solver.hpp"
#include "include/lu_solver.hpp"
#include "include/matrix.hpp"
#include "include/gerschgorin.hpp"
#include "include/lagrange.hpp"
#include "include/least_squares.hpp"
#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    try
    {
        int choice;
        cout << "         Matrix Computation \n";
        cout << "============================================\n";
        cout << "Choose Method:\n";
        cout << "  1. Gaussian Elimination\n";
        cout << "  2. LU - Crout\n";
        cout << "  3. LU - Doolittle\n";
        cout << "  4. LU - Cholesky\n";
        cout << "  5. Gauss-Jacobi\n";
        cout << "  6. Gauss-Seidel\n";
        cout << "  7. Gerschgorin Circle Theorem (eigenvalue bounds)\n";
        cout << "  8. Lagrange Interpolation\n";
        cout << "  9. Least Squares Curve Fitting\n";
        cout << "============================================\n";
        cout << "Enter choice: ";
        cin >> choice;

        if (choice == 8)
        {
            string filename;
            cout << "\nEnter data file name (e.g. Lagrange.txt): ";
            cin >> filename;

            Lagrange lag(filename);//creates object , raed file . store points

            cout << "\n============================================\n";
            cout << "  Lagrange Interpolation\n";
            cout << "============================================\n";
            cout << "  File   : " << filename << "\n";
            cout << "  Points : " << lag.getNumPoints() << "\n";

            lag.displayData();//print table
            lag.printPolynomial();//print final polynomial eq
            lag.queryLoop();//take test value from user

            cout << "\nDone.\n";
            return 0;
        }
        if (choice == 9)
        {
            string filename;
            cout << "\nEnter data file (e.g. curve_data.txt): ";
            cin >> filename;

            cout << "\nSelect model:\n";
            cout << "  1. Linear         (y = a*x + b)\n";
            cout << "  2. Polynomial     (y = a0 + a1*x + ... + an*x^n)\n";
            cout << "  3. Exponential    (y = a*e^(b*x))\n";
            cout << "  4. Power          (y = a*x^b)\n";
            cout << "  5. Logarithmic    (y = a + b*ln(x))\n";
            cout << "Model choice: ";
            int mChoice; cin >> mChoice;

            FitModel fm = FitModel::LINEAR;
            int deg = 1;
            if      (mChoice == 2) { fm = FitModel::POLYNOMIAL;
                                     cout << "Polynomial degree: "; cin >> deg; }
            else if (mChoice == 3)   fm = FitModel::EXPONENTIAL;
            else if (mChoice == 4)   fm = FitModel::POWER;
            else if (mChoice == 5)   fm = FitModel::LOGARITHMIC;

            LeastSquares ls(filename, fm, deg);

            cout << "\n============================================\n";
            cout << "  Least Squares Curve Fitting\n";
            cout << "============================================\n";
            cout << "  File   : " << filename << "\n";
            cout << "  Points : " << ls.getNumPoints() << "\n";

            ls.displayTable();   // uses Matrix::display() under the hood
            ls.fit();
            ls.printSummary();   // equation + R² + RMSE + residuals table
            ls.writeTable("ls_output.txt");
            cout << "Data table written to ls_output.txt\n";
            ls.queryLoop();

            cout << "\nDone.\n";
            return 0;
        }

        int n = 49;
        Matrix augmented(n, n + 1);
        augmented.readFromFile("input.txt");

        Matrix A(n, n);
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                A(i, j) = augmented(i, j);

        cout << "\nMatrix Properties:\n";
        cout << "Is Square: "              << (A.isSquare()             ? "Yes" : "No") << endl;
        cout << "Is Symmetric: "          << (A.isSymmetric()          ? "Yes" : "No") << endl;
        cout << "Is Identity: "           << (A.isIdentity()           ? "Yes" : "No") << endl;
        cout << "Is Null: "               << (A.isNull()               ? "Yes" : "No") << endl;
        cout << "Is Diagonal: "           << (A.isDiagonal()           ? "Yes" : "No") << endl;
        cout << "Is Diagonally Dominant: "<< (A.isDiagonallyDominant() ? "Yes" : "No") << endl;

        vector<double> solution;

        if (choice >= 1 && choice <= 4)
        {
            SystemOfLinearEquation *solver = nullptr;

            if      (choice == 1) solver = new GaussianSolver(n);
            else if (choice == 2) solver = new LUSolver(n, LUSolver::CROUT);
            else if (choice == 3) solver = new LUSolver(n, LUSolver::DOOLITTLE);
            else if (choice == 4) solver = new LUSolver(n, LUSolver::CHOLESKY);

            solver->readFromFile("input.txt");
            solver->solve();
            solution = solver->getSolution();
            delete solver;
        }
        else if (choice == 5 || choice == 6)
        {
            vector<double> b(n);
            for (int i = 0; i < n; i++)
                b[i] = augmented(i, n);

            if (!IterativeSolver::isDiagonallyDominant(A))
            {
                cout << "Matrix is NOT diagonally dominant. Attempting to reorder rows...\n";
                if (IterativeSolver::makeDiagonallyDominant(A, b))
                    cout << "Row reordering successful. Matrix is now diagonally dominant.\n";
                else
                {
                    cout << "Warning: Could not make matrix diagonally dominant by row swapping.\n";
                    cout << "Applying under-relaxation (SOR) for stability.\n";
                }
            }
            else
            {
                cout << "Matrix is diagonally dominant.\n";
            }

            double maxRatio = 0.0;
            for (int i = 0; i < n; i++)
            {
                double diag   = fabs(A(i, i));
                double offSum = 0.0;
                for (int j = 0; j < n; j++)
                    if (j != i) offSum += fabs(A(i, j));
                if (diag > 0) maxRatio = max(maxRatio, offSum / diag);
            }
            double omega     = (maxRatio > 1.0) ? 1.0 / (1.0 + maxRatio) : 1.0;
            int    iterCount = (maxRatio > 1.0) ? 50000 : 1000;

            if (choice == 5)
            {
                if (omega < 1.0)
                    cout << "Using SOR omega = " << omega << " for Gauss-Jacobi stability.\n";
                solution = IterativeSolver::gaussJacobi(A, b, iterCount, 1e-6, omega);
            }
            else
            {
                solution = IterativeSolver::gaussSeidel(A, b, iterCount, 1e-6);
            }
        }
        else if (choice == 7)
        {
            // ---- 49 x 49 ----
            {
                cout << "\n--- Gerschgorin: 49 x 49 matrix (49l.txt) ---\n";
                int sz = 49;
                Matrix A49(sz, sz);
                ifstream f49("49l.txt");
                if (!f49) throw runtime_error("Cannot open 49l.txt");
                for (int i = 0; i < sz; i++)
                {
                    for (int j = 0; j < sz; j++) f49 >> A49(i, j);
                    double dummy; f49 >> dummy;
                }
                f49.close();

                GerschgorinSolver gs49(A49);
                gs49.compute();
                gs49.printResults();

                ofstream out49("gerschgorin_49.txt");
                out49 << fixed << setprecision(4);
                out49 << "Gerschgorin Discs for 49x49 matrix\n";
                out49 << left << setw(6) << "Row" << setw(14) << "Centre"
                      << setw(14) << "Radius" << setw(14) << "Lo" << setw(14) << "Hi" << "\n";
                for (const auto &d : gs49.getDiscs())
                    out49 << setw(6)  << (d.row+1) << setw(14) << d.centre
                          << setw(14) << d.radius  << setw(14) << d.lo << setw(14) << d.hi << "\n";
                out49 << "\nUnion interval: [ " << gs49.getUnionLo()
                      << " , " << gs49.getUnionHi() << " ]\n";
                out49.close();
                cout << "Results written to gerschgorin_49.txt\n";
            }

            // ---- 225 x 225 ----
            {
                cout << "\n--- Gerschgorin: 225 x 225 matrix (225left.txt) ---\n";
                int sz = 225;
                Matrix A225(sz, sz);
                ifstream f225("225left.txt");
                if (!f225) throw runtime_error("Cannot open 225left.txt");
                for (int i = 0; i < sz; i++)
                    for (int j = 0; j < sz; j++) f225 >> A225(i, j);
                f225.close();

                GerschgorinSolver gs225(A225);
                gs225.compute();
                gs225.printResults();

                ofstream out225("gerschgorin_225.txt");
                out225 << fixed << setprecision(4);
                out225 << "Gerschgorin Discs for 225x225 matrix\n";
                out225 << left << setw(6) << "Row" << setw(14) << "Centre"
                       << setw(14) << "Radius" << setw(14) << "Lo" << setw(14) << "Hi" << "\n";
                for (const auto &d : gs225.getDiscs())
                    out225 << setw(6)  << (d.row+1) << setw(14) << d.centre
                           << setw(14) << d.radius  << setw(14) << d.lo << setw(14) << d.hi << "\n";
                out225 << "\nUnion interval: [ " << gs225.getUnionLo()
                       << " , " << gs225.getUnionHi() << " ]\n";
                out225.close();
                cout << "Results written to gerschgorin_225.txt\n";
            }
            return 0;
        }
        else
        {
            cout << "Invalid choice\n";
            return 0;
        }

        ofstream out("output.txt");
        for (int i = 0; i < (int)solution.size(); i++)
            out << "x" << i + 1 << " = " << solution[i] << endl;
        out.close();
        cout << "\nSolution written to output.txt\n";
    }
    catch (exception &e)
    {
        cout << "Error: " << e.what() << endl;
        ofstream out("output.txt");
        out << "Computation failed.\n";
        out.close();
    }

    return 0;
}